"""
    :copyright: © 2019 by the Lin team.
    :license: MIT, see LICENSE for more details.
"""
LOG = {
    'LEVEL': 'DEBUG',
    'DIR': 'logs',
    'SIZE_LIMIT': 1024 * 1024 * 5,
    'REQUEST_LOG': True,
    'FILE': True
}
